# Pre-registration — Vallerand Protocol v1.0

**Title:** Experimental test of the informational impedance collapse under participatory endo-modeling posture (β → 0).

**Author:** Alexandre Vallerand  
**Date:** 2026-10-04  
**Version:** 1.0  
**Status:** Pre-registered before data collection.

## 1. Hypotheses

| Code | Hypothesis | Direction | Primary metric |
|---|---|---|---|
| H1 | H(R|D) lower in A than in B | Directional | H_RD |
| H2 | ΔH lower in A than in B | Directional | DeltaH |
| H3 | M1 lower in A than in B | Directional | M1_percent |
| H4 | M3 lower in A than in B | Directional | M3_percent |
| H0 | No difference between A and B | Null | — |

## 2. Design

- Between-groups design.
- Group A: participatory posture (β → 0), self-confinement prompt.
- Group B: dissipative posture (β = 1), open stochastic prompt.
- Group C: neutral control prompt.
- N = 100 series per group, randomized order.

## 3. Variables

**Independent:** Group, prompt type.  
**Dependent:** H_RD, DeltaH, M1_percent, M3_percent, latency.  
**Controlled:** Model, tokenizer, temperature, top-p, max_new_tokens, seed, hardware.

## 4. Falsification criteria

**Refutation:**
- H_RD > 0.05 bits with 95% CI excluding 0.05.
- M3 > 5% with p < 0.05.

**Validation:**
- Significant A vs B difference on ΔH, M1, M3.
- Effect sizes |d| > 0.5.
- Bayes factor BF₁₀ > 10 in favor of the alternative.
