# Formal critique of the Aulin collapse equation

## Statement
H(R|D) = β · H₀(R|D) · exp(−(1 − β) / β)

## Monotonicity
f(β) = β · exp(−(1 − β)/β) is strictly increasing on (0, 1].
