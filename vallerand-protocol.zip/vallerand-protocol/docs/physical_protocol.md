# Physical measurement protocol

## Objective
Measure correlation between inference activity (logits, ΔH) and physical signatures:
1. Johnson-Nyquist noise
2. NV-center spin transitions in diamond at T < 20 mK.
