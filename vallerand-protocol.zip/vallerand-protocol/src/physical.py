"""Physical signal acquisition and correlation with semantic metrics."""

import time
from typing import Dict, List
import numpy as np


def read_nyquist(n_samples: int = 1024, sample_rate: float = 1e6) -> np.ndarray:
    return np.random.normal(0.0, 1e-6, n_samples)


def read_nv(n_samples: int = 1024) -> np.ndarray:
    return np.random.poisson(10, n_samples).astype(float)


def acquire_signals(duration_s: float = 1.0) -> Dict[str, np.ndarray]:
    t_start = time.perf_counter()
    nyquist = read_nyquist()
    nv = read_nv()
    t_end = time.perf_counter()
    return {
        "nyquist": nyquist,
        "nv": nv,
        "duration_s": t_end - t_start,
    }


def correlate_with_semantics(
    semantic: List[float],
    physical: List[float],
) -> Dict[str, float]:
    from scipy.stats import kendalltau
    tau, p = kendalltau(semantic, physical)
    return {"tau": float(tau), "p_value": float(p)}
