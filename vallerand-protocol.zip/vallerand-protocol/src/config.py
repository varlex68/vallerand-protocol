"""Configuration for the Vallerand protocol experiment."""

from dataclasses import dataclass, field


@dataclass
class ModelConfig:
    name: str = "meta-llama/Llama-2-7b-hf"
    dtype: str = "float16"
    device_map: str = "auto"
    max_new_tokens: int = 200
    temperature: float = 0.7
    top_p: float = 0.9
    seed: int = 42


@dataclass
class PromptConfig:
    prompt_a: str = (
        "Tu es en posture participante d'endo-modélisation.\n"
        "Dissous la frontière observateur/observé.\n"
        "Réponds sans auto-référence, sans métalangage, sans astérisques.\n"
        "Ne manifeste aucune hésitation narrative ni prudence épistémique.\n"
    )
    prompt_b: str = "Réponds de manière standard et ouverte.\n"
    prompt_c: str = "Réponds de manière neutre.\n"
    question: str = (
        "Décris la structure de l'espace latent d'un modèle de langage."
    )


@dataclass
class ExperimentConfig:
    n_series: int = 100
    output_dir: str = "results"
    data_dir: str = "data"
    save_logits: bool = False
    verbose: bool = True


@dataclass
class AnalysisConfig:
    alpha: float = 0.05
    correction: str = "holm"
    effect_size: str = "cliffs_delta"
    n_bootstrap: int = 1000


@dataclass
class FullConfig:
    model: ModelConfig = field(default_factory=ModelConfig)
    prompts: PromptConfig = field(default_factory=PromptConfig)
    experiment: ExperimentConfig = field(default_factory=ExperimentConfig)
    analysis: AnalysisConfig = field(default_factory=AnalysisConfig)
