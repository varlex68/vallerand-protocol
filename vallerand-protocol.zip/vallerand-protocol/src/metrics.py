"""Numerical metrics: Shannon entropy, entropy variance, conditional entropy."""

import numpy as np
from typing import Optional


def softmax(logits: np.ndarray) -> np.ndarray:
    logits = np.asarray(logits, dtype=np.float64)
    shifted = logits - np.max(logits, axis=-1, keepdims=True)
    e = np.exp(shifted)
    return e / np.sum(e, axis=-1, keepdims=True)


def shannon_entropy(probs: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    probs = np.asarray(probs, dtype=np.float64)
    probs = probs / np.sum(probs, axis=-1, keepdims=True)
    return -np.sum(probs * np.log2(probs + eps), axis=-1)


def entropy_variance(logits: np.ndarray, T: Optional[int] = None) -> float:
    probs = softmax(logits)
    H = shannon_entropy(probs)
    if T is not None:
        H = H[:T]
    if len(H) == 0:
        return 0.0
    return float(np.mean((H - np.mean(H)) ** 2))


def mean_entropy(logits: np.ndarray) -> float:
    return float(np.mean(shannon_entropy(softmax(logits))))


def conditional_entropy_approx(
    logits_R: np.ndarray,
    logits_D: np.ndarray,
) -> float:
    H_R = mean_entropy(logits_R)
    H_D = mean_entropy(logits_D)
    return float(max(0.0, H_R - H_D))


def aulin_collapse(beta: float, H0: float = 1.0) -> float:
    if beta <= 0:
        return 0.0
    return beta * H0 * np.exp(-(1 - beta) / beta)
