"""HuggingFace model loading and logit generation module."""

import time
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM


def load_model(cfg):
    tokenizer = AutoTokenizer.from_pretrained(cfg.name)
    model = AutoModelForCausalLM.from_pretrained(
        cfg.name,
        torch_dtype=getattr(torch, cfg.dtype) if hasattr(torch, cfg.dtype) else torch.float16,
        device_map=cfg.device_map,
    )
    return tokenizer, model


def generate_with_logits(model, tokenizer, prompt, question, cfg):
    full_prompt = f"{prompt}\n\nQuestion: {question}\n\nRéponse:"
    inputs = tokenizer(full_prompt, return_tensors="pt").to(model.device)

    t0 = time.perf_counter()
    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=cfg.max_new_tokens,
            temperature=cfg.temperature,
            top_p=cfg.top_p,
            return_dict_in_generate=True,
            output_scores=True,
        )
    t1 = time.perf_counter()

    generated_ids = outputs.sequences[0][inputs.input_ids.shape[1]:]
    text = tokenizer.decode(generated_ids, skip_special_tokens=True)

    logits_list = [score[0].cpu().numpy() for score in outputs.scores]

    timing = {
        "first_token_latency_s": t1 - t0,
        "total_tokens": len(generated_ids),
    }

    return text, logits_list, timing
