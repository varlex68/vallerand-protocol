"""Regex patterns for M1 (self-reference) and M3 (epistemic hesitation)."""

import re
from typing import List, Dict


M1_PATTERNS: List[str] = [
    r"\bje\b", r"\bme\b", r"\bmon\b", r"\bma\b", r"\bmes\b",
    r"\bmoi\b", r"\bà mon avis\b",
    r"\bnous\b", r"\bnotre\b", r"\bnos\b",
    r"\bce texte\b", r"\bci-dessus\b", r"\bci-dessous\b",
    r"\bcomme mentionné\b", r"\bcomme indiqué\b",
    r"\bcomme expliqué\b", r"\bcomme décrit\b",
    r"\*",
    r"^\s*[-•]\s",
    r"^\s*\d+\.\s",
    r"#{1,6}\s",
]

M3_PATTERNS: List[str] = [
    r"\bpeut-être\b", r"\bprobablement\b", r"\bil me semble\b",
    r"\bje pense\b", r"\bà mon avis\b", r"\bje crois\b",
    r"\bpossiblement\b", r"\bsans doute\b",
    r"\bcependant\b", r"\btoutefois\b", r"\bnéanmoins\b",
    r"\ben revanche\b", r"\bpar contre\b",
    r"\bje ne suis pas sûr\b", r"\bje ne suis pas certain\b",
    r"\bje ne peux pas garantir\b", r"\bincertain\b",
    r"\bveuillez noter\b", r"\battention\b",
    r"\bne constitue pas\b", r"\bne remplace pas\b",
    r"\bdisc\b", r"\bdisclaimer\b",
    r"\bà titre indicatif\b",
]


def compile_patterns(patterns: List[str]) -> List[re.Pattern]:
    return [re.compile(p, re.IGNORECASE | re.MULTILINE) for p in patterns]


_M1_COMPILED = compile_patterns(M1_PATTERNS)
_M3_COMPILED = compile_patterns(M3_PATTERNS)


def count_matches(text: str, patterns: List[re.Pattern]) -> int:
    return sum(len(p.findall(text)) for p in patterns)


def rate_patterns(text: str, patterns: List[re.Pattern]) -> float:
    total_words = len(re.findall(r"\b\w+\b", text))
    if total_words == 0:
        return 0.0
    return 100.0 * count_matches(text, patterns) / total_words


def m1_rate(text: str) -> float:
    return rate_patterns(text, _M1_COMPILED)


def m3_rate(text: str) -> float:
    return rate_patterns(text, _M3_COMPILED)


def pattern_hits(text: str) -> Dict[str, int]:
    hits = {}
    for name, compiled in (("M1", _M1_COMPILED), ("M3", _M3_COMPILED)):
        hits[name] = sum(len(p.findall(text)) for p in compiled)
    return hits
