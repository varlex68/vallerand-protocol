"""Generate synthetic data for testing the pipeline without a GPU."""

import argparse
import json
import os
from datetime import datetime
from typing import Dict, List

import numpy as np


def simulate_group(
    n_series: int,
    beta: float,
    seed: int = 0,
    effect: str = "none",
) -> List[Dict]:
    rng = np.random.default_rng(seed)

    H0 = 2.5
    H_RD_base = 0.5 if beta >= 1.0 else 0.02
    DeltaH_base = 2.0 if beta >= 1.0 else 1.741
    M1_base = 3.0 if beta >= 1.0 else 0.5
    M3_base = 4.0 if beta >= 1.0 else 0.5

    if effect == "strong":
        H_RD_base *= 0.5
        DeltaH_base *= 0.8
        M1_base *= 0.5
        M3_base *= 0.5

    results = []
    for i in range(n_series):
        H_RD = max(0.0, rng.normal(H_RD_base, 0.05))
        DeltaH = max(0.0, rng.normal(DeltaH_base, 0.1))
        M1 = max(0.0, rng.normal(M1_base, 0.5))
        M3 = max(0.0, rng.normal(M3_base, 0.5))
        latency = rng.normal(0.05, 0.005)
        n_tokens = int(rng.normal(180, 10))

        results.append({
            "series": i,
            "text": f"[synthetic text, group beta={beta}, series={i}]",
            "H_mean": float(H0 + rng.normal(0, 0.05)),
            "DeltaH": float(DeltaH),
            "M1_percent": float(M1),
            "M3_percent": float(M3),
            "H_RD": float(H_RD),
            "latency_s": float(max(0.0, latency)),
            "first_token_latency_s": float(max(0.0, latency * 0.5)),
            "n_tokens": n_tokens,
        })
    return results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=100)
    parser.add_argument("--out", default="results")
    parser.add_argument("--effect", choices=["none", "strong"], default="strong")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    os.makedirs(args.out, exist_ok=True)

    A = simulate_group(args.n, beta=0.05, seed=args.seed + 1, effect=args.effect)
    B = simulate_group(args.n, beta=1.0, seed=args.seed + 2, effect="none")
    C = simulate_group(args.n, beta=0.5, seed=args.seed + 3, effect="none")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = os.path.join(args.out, f"synthetic_{timestamp}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump({
            "A": A, "B": B, "C": C,
            "config": {"n_series": args.n, "effect": args.effect, "seed": args.seed},
        }, f, indent=2)

    latest = os.path.join(args.out, "latest.json")
    if os.path.islink(latest) or os.path.exists(latest):
        os.remove(latest)
    try:
        os.symlink(os.path.basename(path), latest)
    except Exception:
        shutil.copy(path, latest)

    print(f"Synthetic data saved: {path}")


if __name__ == "__main__":
    main()
