"""Main entry point for the Vallerand protocol experiment."""

import argparse
import json
import os
import time
from datetime import datetime

import numpy as np

from .config import FullConfig
from .generation import load_model, generate_with_logits
from .metrics import (
    entropy_variance,
    mean_entropy,
    conditional_entropy_approx,
)
from .patterns import m1_rate, m3_rate


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="meta-llama/Llama-2-7b-hf")
    parser.add_argument("--n", type=int, default=100)
    parser.add_argument("--out", default="results")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    print(f"Vallerand Protocol Pipeline Initialized for model {args.model} with N={args.n}")


if __name__ == "__main__":
    main()
