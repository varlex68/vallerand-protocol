"""Frequentist statistical analysis."""

import argparse
import json
from typing import List, Dict, Any

import numpy as np
from scipy.stats import mannwhitneyu, kendalltau


def descriptive(values: List[float]) -> Dict[str, float]:
    a = np.array(values, dtype=np.float64)
    return {
        "mean": float(np.mean(a)),
        "median": float(np.median(a)),
        "std": float(np.std(a, ddof=1)) if len(a) > 1 else 0.0,
        "ci95_low": float(np.percentile(a, 2.5)),
        "ci95_high": float(np.percentile(a, 97.5)),
        "n": int(len(a)),
    }


def cliffs_delta(a: np.ndarray, b: np.ndarray) -> float:
    n_a, n_b = len(a), len(b)
    if n_a == 0 or n_b == 0:
        return 0.0
    delta = 0.0
    for x in a:
        delta += np.sum(np.sign(x - b))
    return float(delta / (n_a * n_b))


def compare(a: List[float], b: List[float], metric: str) -> Dict[str, Any]:
    a_arr = np.array(a, dtype=np.float64)
    b_arr = np.array(b, dtype=np.float64)
    stat, p = mannwhitneyu(a_arr, b_arr, alternative="two-sided")
    return {
        "metric": metric,
        "mean_A": float(np.mean(a_arr)),
        "mean_B": float(np.mean(b_arr)),
        "median_A": float(np.median(a_arr)),
        "median_B": float(np.median(b_arr)),
        "U": float(stat),
        "p_value": float(p),
        "cliffs_delta": cliffs_delta(a_arr, b_arr),
    }


def holm_correction(p_values: List[float]) -> List[float]:
    m = len(p_values)
    order = np.argsort(p_values)
    adjusted = np.zeros(m)
    prev = 0.0
    for rank, idx in enumerate(order):
        val = (m - rank) * p_values[idx]
        val = min(1.0, max(val, prev))
        adjusted[idx] = val
        prev = val
    return adjusted.tolist()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", required=True)
    args = parser.parse_args()

    with open(args.results, "r", encoding="utf-8") as f:
        payload = json.load(f)

    groups = {k: payload[k] for k in ("A", "B", "C") if k in payload}
    metrics = ["H_RD", "DeltaH", "M1_percent", "M3_percent"]

    report = {"descriptive": {}, "comparisons": {}}
    for m in metrics:
        report["descriptive"][m] = {
            g: descriptive([r[m] for r in groups[g]]) for g in groups
        }
        report["comparisons"][m] = {
            "A_vs_B": compare([r[m] for r in groups["A"]],
                              [r[m] for r in groups["B"]], m),
        }
        if "C" in groups:
            report["comparisons"][m]["A_vs_C"] = compare(
                [r[m] for r in groups["A"]],
                [r[m] for r in groups["C"]], m,
            )

    p_list = [report["comparisons"][m]["A_vs_B"]["p_value"] for m in metrics]
    adjusted = holm_correction(p_list)
    for m, p_adj in zip(metrics, adjusted):
        report["comparisons"][m]["A_vs_B"]["p_holm"] = p_adj

    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
