#!/usr/bin/env bash
set -euo pipefail

MODEL="${MODEL:-meta-llama/Llama-2-7b-hf}"
N="${N:-100}"
OUT="${OUT:-results}"

python -m src.main --model "$MODEL" --n "$N" --out "$OUT"
