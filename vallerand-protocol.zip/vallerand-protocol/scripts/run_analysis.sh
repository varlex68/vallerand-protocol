#!/usr/bin/env bash
set -euo pipefail

RESULTS="${RESULTS:-results/latest.json}"
python -m src.analysis --results "$RESULTS"
