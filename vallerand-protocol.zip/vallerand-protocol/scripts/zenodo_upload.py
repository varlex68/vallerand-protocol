#!/usr/bin/env python3
"""Zenodo upload helper script."""

import argparse
import json
import os
import sys

print("Zenodo Uploader Ready")
