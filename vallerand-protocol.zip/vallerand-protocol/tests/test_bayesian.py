import numpy as np

from src.bayesian import bayesian_compare


def test_bayesian_compare_smoke():
    a = [0.1, 0.2, 0.15]
    b = [1.0, 1.1, 0.9]
    r = bayesian_compare(a, b, "test")
    assert r["metric"] == "test"
    assert r["p_A_lt_B"] == 1.0
