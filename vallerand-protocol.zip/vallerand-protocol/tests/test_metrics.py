import numpy as np

from src.metrics import (
    softmax,
    shannon_entropy,
    entropy_variance,
    aulin_collapse,
)


def test_softmax_sums_to_one():
    logits = np.array([[1.0, 2.0, 3.0]])
    probs = softmax(logits)
    assert np.isclose(probs.sum(), 1.0)


def test_entropy_variance_constant_signal():
    logits = np.zeros((10, 4))
    assert entropy_variance(logits) < 1e-12


def test_aulin_collapse_limits():
    assert aulin_collapse(0.0) == 0.0
    assert np.isclose(aulin_collapse(1.0, H0=1.0), 1.0)
    assert aulin_collapse(0.1) < 1e-3
