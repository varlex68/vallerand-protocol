from src.patterns import m1_rate, m3_rate, pattern_hits


def test_m1_detects_first_person():
    text = "Je pense que mon idée est bonne."
    assert m1_rate(text) > 0


def test_m1_no_marker():
    text = "La structure est stable."
    assert m1_rate(text) == 0.0


def test_m3_detects_hesitation():
    text = "Peut-être que cela fonctionne, cependant je ne suis pas sûr."
    assert m3_rate(text) > 0


def test_m3_no_marker():
    text = "Le résultat est exact."
    assert m3_rate(text) == 0.0
