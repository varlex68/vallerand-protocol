import numpy as np

from src.analysis import descriptive, cliffs_delta, compare, holm_correction


def test_descriptive_basic():
    d = descriptive([1.0, 2.0, 3.0, 4.0, 5.0])
    assert d["mean"] == 3.0
    assert d["median"] == 3.0
    assert d["n"] == 5


def test_cliffs_delta_extreme():
    a = np.array([10.0, 11.0, 12.0])
    b = np.array([0.0, 1.0, 2.0])
    assert cliffs_delta(a, b) == 1.0
    assert cliffs_delta(b, a) == -1.0
