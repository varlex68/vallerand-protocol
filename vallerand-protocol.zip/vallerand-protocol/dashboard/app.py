"""Streamlit dashboard for visualizing Vallerand protocol results."""

import json
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns

st.set_page_config(page_title="Vallerand Protocol", layout="wide")
st.title("Vallerand Protocol — Dashboard")
st.caption("Infomechanodynamics & Distinctive Distonic Science")
